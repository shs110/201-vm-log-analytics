﻿configuration createTextFile
{
   param
    (
        [Parameter(Mandatory)]
        [string]$vmTagValue
    )

    
    Node localhost{

    foreach($feature in $features)
    {
    
        File CreateFile {
            DestinationPath = 'C:\Temp\sampledata.txt'
            Ensure = "Present"
            Contents = '$vmTagValue'
        }
        Log "netserverWindowsFeatures-$feature"
            {
                Message = "netserverWindowsFeatures Windows $feature updated"
                #DependsOn = "[WindowsFeature]"
            }


    }
    }
}